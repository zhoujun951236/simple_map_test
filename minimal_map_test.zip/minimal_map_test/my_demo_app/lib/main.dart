import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // TRY THIS: Try running your application with "flutter run". You'll see
        // the application has a purple toolbar. Then, without quitting the app,
        // try changing the seedColor in the colorScheme below to Colors.green
        // and then invoke "hot reload" (save your changes or press the "hot
        // reload" button in a Flutter-supported IDE, or press "r" if you used
        // the command line to start the app).
        //
        // Notice that the counter didn't reset back to zero; the application
        // state is not lost during the reload. To reset the state, use hot
        // restart instead.
        //
        // This works for code too, not just values: Most code changes can be
        // tested with just a hot reload.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Map Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  final MapController _mapController = MapController();

  void _incrementCounter() {
    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    int interactiveFlags = InteractiveFlag.doubleTapZoom | //
        InteractiveFlag.drag |
        InteractiveFlag.scrollWheelZoom |
        InteractiveFlag.pinchZoom |
        InteractiveFlag.pinchMove;
    LatLng center = const LatLng(40.405285, 5.904989);
    return Scaffold(
      appBar: AppBar(
        // TRY THIS: Try changing the color here to a specific color (to
        // Colors.amber, perhaps?) and trigger a hot reload to see the AppBar
        // change color while the other colors stay the same.
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title),
      ),
      body: FlutterMap(
        mapController: _mapController,
        options: MapOptions(
          initialCenter: center,
          initialZoom: 3, //11
          interactionOptions: InteractionOptions(flags: interactiveFlags),
          onTap: (tapPosition, point) {},
          onMapEvent: (mapEvent) async {},
        ),
        children: const [
          StringGeoJSONPolygon(),
        ],
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}

class StringGeoJSONPolygon extends StatelessWidget {
  const StringGeoJSONPolygon({super.key, this.mapController});

  final MapController? mapController;

  @override
  Widget build(BuildContext context) {
    // 假设你的 polygons.geojson 已加载为字符串
    String geoJsonString = '''{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "id": 1,
      "geometry": {
        "type": "Polygon",
        "coordinates": [
          [
            [
              -8.0279531358941529,
              31.599606879864105
            ],
            [
              -8.0269109608071592,
              31.598612704918242
            ],
            [
              -8.0230757591101476,
              31.598648211567625
            ],
            [
              -8.0214499665493815,
              31.59910979371768
            ],
            [
              -8.0207829755357629,
              31.602305302533416
            ],
            [
              -8.0172395825756553,
              31.602198787492433
            ],
            [
              -8.0171978953565848,
              31.603903015823661
            ],
            [
              -8.0170728345976681,
              31.60557170896902
            ],
            [
              -8.0525901395352459,
              31.608838000822622
            ],
            [
              -8.0531737570090538,
              31.606423796550846
            ],
            [
              -8.029912423512565,
              31.603689988509714
            ],
            [
              -8.0279531358941529,
              31.599606879864105
            ]
          ]
        ]
      },
      "properties": {
        "OBJECTID": 1,
        "Shape_Length": 9541.5849195179835,
        "Shape_Area": 2012588.8060659999,
        "Name": "Aeroport El Menara"
      }
    },
    {
      "type": "Feature",
      "id": 2,
      "geometry": {
        "type": "Polygon",
        "coordinates": [
          [
            [
              -7.9807383385343513,
              31.583855389531053
            ],
            [
              -7.9659491808741087,
              31.586564706223932
            ],
            [
              -7.976126665445098,
              31.613788967621367
            ],
            [
              -7.9874173126717798,
              31.609861580256151
            ],
            [
              -7.9807383385343513,
              31.583855389531053
            ]
          ]
        ]
      },
      "properties": {
        "OBJECTID": 2,
        "Shape_Length": 10255.053922467163,
        "Shape_Area": 5456316.9894769555,
        "Name": "Agdal Gardens"
      }
    },
    {
      "type": "Feature",
      "id": 3,
      "geometry": {
        "type": "Polygon",
        "coordinates": [
          [
            [
              -5.8564915474747492,
              35.741475846113893
            ],
            [
              -5.8565126249119928,
              35.741540441529459
            ],
            [
              -5.8565366460571111,
              35.741604354285641
            ],
            [
              -5.8565635879107596,
              35.741667498466882
            ],
            [
              -5.8565934249748848,
              35.741729777532029
            ],
            [
              -5.8566261348853974,
              35.741791098712611
            ],
            [
              -5.8566616952029724,
              35.741851365346648
            ],
            [
              -5.8567000835343039,
              35.741910477718797
            ],
            [
              -5.856741277023672,
              35.741968332526874
            ],
            [
              -5.8567852517570538,
              35.742024822356733
            ],
            [
              -5.8568319820666233,
              35.742079835170998
            ],
            [
              -5.8568814402026463,
              35.742133254317515
            ],
            [
              -5.856933593742391,
              35.742184956299525
            ],
            [
              -5.8569884066083873,
              35.742234812693347
            ],
            [
              -5.8570458366675933,
              35.742282688511118
            ],
            [
              -5.8571058346158447,
              35.742328442284169
            ],
            [
              -5.8571683422921108,
              35.742371925895341
            ],
            [
              -5.857233290947657,
              35.742412984717298
            ],
            [
              -5.8573005992995979,
              35.742451457950487
            ],
            [
              -5.8573701714326667,
              35.742487179260941
            ],
            [
              -5.8574418945920215,
              35.74251997778547
            ],
            [
              -5.8575156370223143,
              35.742549679606327
            ],
            [
              -5.8575912455261419,
              35.742576109590978
            ],
            [
              -5.8576685435556604,
              35.74259909395839
            ],
            [
              -5.857747351563984,
              35.742618468222574
            ],
            [
              -5.8578273958390792,
              35.742634060000768
            ],
            [
              -5.8579084467236324,
              35.742645726939138
            ],
            [
              -5.857990226026824,
              35.742653337018602
            ],
            [
              -5.8580724317671606,
              35.742656779472135
            ],
            [
              -5.8581547413167989,
              35.74265596937596
            ],
            [
              -5.85823681589142,
              35.742650851801969
            ],
            [
              -5.858318306264847,
              35.742641405172897
            ],
            [
              -5.8583988640727114,
              35.742627642568642
            ],
            [
              -5.8584781258648304,
              35.74260961718651
            ],
            [
              -5.8585557667252504,
              35.742587412476105
            ],
            [
              -5.8586314607860039,
              35.742561149225381
            ],
            [
              -5.8587049103171331,
              35.742530977519152
            ],
            [
              -5.8587758457397356,
              35.742497073219603
            ],
            [
              -5.8588440288001138,
              35.742459632881484
            ],
            [
              -5.8589092542226053,
              35.742418868410198
            ],
            [
              -5.8589713499375344,
              35.742375001817457
            ],
            [
              -5.8590301760866792,
              35.74232826036242
            ],
            [
              -5.8590856230705439,
              35.742278872280671
            ],
            [
              -5.8591376089211789,
              35.742227063215466
            ],
            [
              -5.8591860762697738,
              35.742173053388377
            ],
            [
              -5.8592309891414569,
              35.742117055485508
            ],
            [
              -5.8592723297617706,
              35.742059273195053
            ],
            [
              -5.8593100955093256,
              35.741999900307803
            ],
            [
              -5.8593442961033588,
              35.741939120284101
            ],
            [
              -5.8593749510765516,
              35.741877106191779
            ],
            [
              -5.859402087553752,
              35.741814020928047
            ],
            [
              -5.8594257383358563,
              35.741750017649679
            ],
            [
              -5.8594459402738366,
              35.741685240348886
            ],
            [
              -5.8594627329094235,
              35.741619824524612
            ],
            [
              -5.8594761573547443,
              35.741553897910251
            ],
            [
              -5.859486255382075,
              35.741487581228945
            ],
            [
              -5.8594930686957554,
              35.741420988955355
            ],
            [
              -5.859496638360346,
              35.741354230069547
            ],
            [
              -5.8594970043619652,
              35.741287408793639
            ],
            [
              -5.8594942052827372,
              35.741220625305921
            ],
            [
              -5.8594882780713986,
              35.74115397642997
            ],
            [
              -5.859479257896103,
              35.741087556298183
            ],
            [
              -5.8594671781117098,
              35.74102145720196
            ],
            [
              -5.859452070250379,
              35.740955770029217
            ],
            [
              -5.8594339628602405,
              35.740890580846255
            ],
            [
              -5.8594128855572958,
              35.740825985531458
            ],
            [
              -5.8593888642499001,
              35.740762071886969
            ],
            [
              -5.8593619229375156,
              35.740698928342056
            ],
            [
              -5.8593320858498705,
              35.740636648428037
            ],
            [
              -5.8592993758973559,
              35.740575326291406
            ],
            [
              -5.8592638155114178,
              35.740515058594809
            ],
            [
              -5.8592254270764048,
              35.740455945056013
            ],
            [
              -5.8591842334383548,
              35.740398088981628
            ],
            [
              -5.8591402585012924,
              35.740341597792778
            ],
            [
              -5.85909352793003,
              35.740286583544247
            ],
            [
              -5.8590440699335131,
              35.740233163383607
            ],
            [
              -5.858991916239634,
              35.74018146004974
            ],
            [
              -5.8589371031524804,
              35.740131602246969
            ],
            [
              -5.8588796727966894,
              35.740083724980153
            ],
            [
              -5.8588196745269654,
              35.740037969779344
            ],
            [
              -5.858757166517381,
              35.739994484784418
            ],
            [
              -5.8586922175325453,
              35.739953424644455
            ],
            [
              -5.8586249088728151,
              35.739914950178644
            ],
            [
              -5.8585553228319256,
              35.739879221119551
            ],
            [
              -5.8584835964029667,
              35.739846421019337
            ],
            [
              -5.8584098523746286,
              35.739816718658552
            ],
            [
              -5.8583342436668024,
              35.739790288822881
            ],
            [
              -5.8582569464088374,
              35.739767304977356
            ],
            [
              -5.858178161592785,
              35.739747936200587
            ],
            [
              -5.8580981161664161,
              35.739732343545434
            ],
            [
              -5.8580170633429747,
              35.739720675892265
            ],
            [
              -5.8579352819080803,
              35.739713065429228
            ],
            [
              -5.8578530744032493,
              35.739709622970643
            ],
            [
              -5.8577707645371664,
              35.739710433352748
            ],
            [
              -5.8576886868230371,
              35.73971555166078
            ],
            [
              -5.8576071978373729,
              35.739724998880241
            ],
            [
              -5.8575266466389433,
              35.7397387610484
            ],
            [
              -5.8574473828107436,
              35.739756787611533
            ],
            [
              -5.85736974184461,
              35.739778993275664
            ],
            [
              -5.8572940511634437,
              35.739805256308038
            ],
            [
              -5.8572206034848957,
              35.739835428153818
            ],
            [
              -5.8571496696162768,
              35.739869332586665
            ],
            [
              -5.8570814877344102,
              35.739906773122051
            ],
            [
              -5.8570162630908849,
              35.739947537916237
            ],
            [
              -5.8569541677725763,
              35.739991405003259
            ],
            [
              -5.8568953416830922,
              35.740038147150528
            ],
            [
              -5.8568398944832358,
              35.740087536129955
            ],
            [
              -5.8567879082081049,
              35.740139346288963
            ],
            [
              -5.8567394397866632,
              35.740193357979066
            ],
            [
              -5.8566945258611973,
              35.740249357893092
            ],
            [
              -5.8566531862515303,
              35.740307139329552
            ],
            [
              -5.8566154195225284,
              35.740366514147283
            ],
            [
              -5.8565812180796328,
              35.740427296046725
            ],
            [
              -5.8565505623856291,
              35.740489311928847
            ],
            [
              -5.8565234253052578,
              35.740552398874982
            ],
            [
              -5.856499774024952,
              35.740616403713652
            ],
            [
              -5.856479571680838,
              35.740681182442394
            ],
            [
              -5.8564627787189991,
              35.740746599554967
            ],
            [
              -5.8564493540161413,
              35.740812527312713
            ],
            [
              -5.8564392557898728,
              35.740878844989012
            ],
            [
              -5.8564324423267529,
              35.740945438107381
            ],
            [
              -5.85642887255411,
              35.741012197687667
            ],
            [
              -5.8564285064787454,
              35.741079019509371
            ],
            [
              -5.856431305412408,
              35.741145801867653
            ],
            [
              -5.8564372326450087,
              35.741212452025657
            ],
            [
              -5.8564462528560242,
              35.741278872667962
            ],
            [
              -5.8564583327153388,
              35.741344972075915
            ],
            [
              -5.8564734407894834,
              35.741410659800877
            ],
            [
              -5.8564915474747492,
              35.741475846113893
            ]
          ]
        ]
      },
      "properties": {
        "OBJECTID": 3,
        "Shape_Length": 1173.1509078840431,
        "Shape_Area": 108048.2887734777,
        "Name": "Grande Stade Tangier"
      }
    },
    {
      "type": "Feature",
      "id": 4,
      "geometry": {
        "type": "Polygon",
        "coordinates": [
          [
            [
              -5.5390961179033447,
              35.854938732732805
            ],
            [
              -5.5282062091249369,
              35.865744025852457
            ],
            [
              -5.5227103674206548,
              35.871517242688597
            ],
            [
              -5.51497547936229,
              35.874980970747416
            ],
            [
              -5.5058157428890544,
              35.882815035370264
            ],
            [
              -5.5009305498638046,
              35.883474710750995
            ],
            [
              -5.4942134099031934,
              35.880341204120704
            ],
            [
              -5.4856643230072875,
              35.884958960631892
            ],
            [
              -5.4814915541894571,
              35.889164182654511
            ],
            [
              -5.4765045865340856,
              35.891802639658032
            ],
            [
              -5.4817968789781224,
              35.89625483611583
            ],
            [
              -5.4898370918251516,
              35.900294575627022
            ],
            [
              -5.4947222848504005,
              35.900624341193755
            ],
            [
              -5.5044926700026364,
              35.893863872833919
            ],
            [
              -5.5081565647715891,
              35.888092284564941
            ],
            [
              -5.5081565647715891,
              35.885288790080281
            ],
            [
              -5.510599160385917,
              35.883309792784871
            ],
            [
              -5.5173163003464953,
              35.883144873747455
            ],
            [
              -5.5225068181604087,
              35.883804546380937
            ],
            [
              -5.533905600987727,
              35.880506128996053
            ],
            [
              -5.5397067674806744,
              35.874733567142144
            ],
            [
              -5.5464239074412518,
              35.862857260073547
            ],
            [
              -5.5474416555390382,
              35.86038280488674
            ],
            [
              -5.5390961179033447,
              35.854938732732805
            ]
          ]
        ]
      },
      "properties": {
        "OBJECTID": 4,
        "Shape_Length": 21935.461485045889,
        "Shape_Area": 13605126.78425467,
        "Name": "Tanger-Med"
      }
    }
  ]
}''';
    Map<String, dynamic> geoJson = json.decode(geoJsonString);

    List<Polygon> polygons = [];
    for (var feature in geoJson['features']) {
      List<LatLng> points = [];
      for (var coordinate in feature['geometry']['coordinates'][0]) {
        double lat = coordinate[1];
        double lon = coordinate[0];
        points.add(LatLng(lat, lon));
      }
      polygons.add(
        Polygon(
          points: points,
          color: const Color(0xFFA29A0A), //  .withOpacity(0.5)
          borderColor: Colors.red,
          borderStrokeWidth: 2.0,
        ),
      );
    }
    return PolygonLayer(
      polygons: polygons,
    );
  }
}
